// Choose the word that matches your birthday.

1. Accessibility
2. API
3. Backend
4. Breakpoints
5. Browser
6. Browser compatibility
7. Bug
8. Code review
9. Cookies
10. CSS
11. Framework
12. Frontend
13. Github
14. HTML
15. Http
16. Https
17. JavaScript
18. Node.js
19. Metadata
20. Mob programming
21. Open Source
22. Pair Programming
23. React
24. Responsive design
25. SASS
26. Scrum
27. SEO
28. Stackoverflow
29. URL
30. Web Server
31. Web standards
